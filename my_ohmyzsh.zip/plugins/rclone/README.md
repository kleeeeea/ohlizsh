# Rclone plugin

This plugin adds completion for [Rclone](https://rclone.org/), the command-line program to manage files on cloud storage.

To use it, add `rclone` to the plugins array in your zshrc file:

```zsh
plugins=(... rclone)
```
