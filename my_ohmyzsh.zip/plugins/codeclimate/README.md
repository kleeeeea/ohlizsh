# codeclimate plugin

This plugin adds autocompletion for the [`codeclimate` CLI](https://github.com/codeclimate/codeclimate).

To use it, add `codeclimate` to the plugins array in your zshrc file:
```zsh
plugins=(... codeclimate)
```
